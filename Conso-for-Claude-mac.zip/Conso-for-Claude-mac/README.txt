Double-click "Install Conso.command".

If macOS refuses to open it (unidentified developer):
right-click the file > Open, then Open again.

To update later, run the same file again.

----

Double-clique sur « Install Conso.command ».

Si macOS refuse de l'ouvrir (développeur non identifié) :
clic droit sur le fichier > Ouvrir, puis de nouveau Ouvrir.

Pour mettre à jour plus tard, relance le même fichier.
